#App7



### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ###
### 1. LOADING ####
### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### 
library(ggplot2)
library(shiny)
library(plotly)
library(DT)
library(visNetwork)
library(reshape2)
library(shinythemes)
SM_MOA <- read.csv(file="data/L1000_SM_MOA2.csv", header=TRUE)



### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ###
### 2. UI ####
### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### 
ui <- navbarPage(  theme = shinytheme("flatly"),responsive = TRUE,
                   title = div(
                              img(src = "Logos_3.png",height="30",align="left",position="fixed",hspace="10"),
                              "SynergySeq"
                              ),
                  
                   ### UI Introduction ####
                   source("tabs/introduction_UI.R",  local = TRUE)$value,
                  
                   
                   tabPanel("Tools", tabsetPanel(
                     
                            ### UI Tool1 ####
                            source("tabs/Tool1_synergy_plot_with_reference_UI.R",  local = TRUE)$value,
                            
                            
                            ### UI Tool2 ####
                            source("tabs/Tool2_synergy_plot_no_reference_UI.R",  local = TRUE)$value,
                            
                            
                            
                            ### UI Tool3 ####
                            source("tabs/Tool3_Single_Cell_UI.R",  local = TRUE)$value
                            
                            )),
                   
                  
                  
                   ### UI About ####
                   source("tabs/about.R",  local = TRUE)$value
              )
 


### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ###
### 3. SERVER ####
### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### ### 
server <- function(input, output)
                {
### Tool1  ####
source("tabs/Tool1_synergy_plot_with_reference_SERVER.R",  local = TRUE)$value
  
### Tool2  ####
  
## -> only for evaluation, delete in final version
T2_values <- reactiveValues()
                  
observeEvent(eventExpr=input$T2_Disease,ignoreInit = TRUE, {
              datasetInput_Dis <- switch(input$T2_Disease,
                                         "Glioblastoma TCGA (GBM)" = "data/TCGA_GBM_Signature.txt",
                                         "Colon TCGA (CRC)" = "data/TCGA_CRC_Signature.txt",
                                         "Breast TCGA (BRCA)" = "data/TCGA_BRCA_Signature.txt",
                                         "PDX GBM Group 1" = "data/Table_G1_1_PDX_Group1_L1000_only.txt",
                                         "PDX GBM Group 2" = "data/Table_G2_1_PDX_Group2_L1000_only.txt",
                                         "PDX GBM Group 3" = "data/Table_G3_1_PDX_Group3_L1000_only.txt" ,
                                         "PDX GBM Group 4" = "data/Table_G4_1_PDX_Group4_L1000_only.txt")
              T2_Temp1 <- read.table(file=datasetInput_Dis,header = TRUE,sep = "\t")
              T2_values$Disease_Signature <- T2_Temp1
              T2_values$Disease_input <- input$T2_Disease
})
                  
                  
observeEvent(eventExpr=input$T2_go_disease_signature,ignoreInit = TRUE, {
  T2_Temp2 <- read.table(text=input$T2_Disease_Text_Box,sep=",")
  colnames(T2_Temp2) <- c("Genes","log2FoldChange")
  T2_values$Disease_Signature <- T2_Temp2
  T2_values$Disease_input <- "Custom Disease Signature"
})


T2_TCS_Flavors <- read.delim(file="data/Final_TCS_Signature_Correlation_02_14_2019.txt")
T2_TCS_Flavor_Metadata <- read.delim(file="data/Final_TCS_Signature_Correlation_Metadata_02_14_2019.txt")
T2_Similarity <- read.table(file="data/TCS_Weighted_SR.txt")

output$T2_plot1 <- renderPlotly({
  
T2_Similarity <-read.delim(file="data/TCS_Flavors_Weighted_SR.txt",check.names = FALSE,row.names=1)


})







T2_Drug_Sig_Threshold <- 50

T2_Drug_Signatures <- reactive({
  Drugs_Sigs <- read.table(file="data/matPH3_2_1_0.2_0.3_L1000_Batch2017_Regina_removed.txt",sep ="\t", header=TRUE)
  Drugs_Sigs <- na.omit(Drugs_Sigs)
  row.names(Drugs_Sigs) <-  as.character(Drugs_Sigs$Genes)
  Drugs_Sigs <- Drugs_Sigs[,-1]
  T2_Sum <- apply(Drugs_Sigs,1,function(x){ length(x[x!=0])})
  T2_Sum2 <- T2_Sum[T2_Sum > T2_Drug_Sig_Threshold]
  Drugs_Sigs <- Drugs_Sigs[names(T2_Sum2),]
  Drugs_Sigs
                  })


T2_Drug_Similarity_Metrics <- reactive ({switch(input$T2_Simil_metric,
                           "Similarity Ratio" = "data/TCS_Old_SR.txt",
                           "Weighted Similarity Ratio" = "data/TCS_Weighted_SR.txt",
                           "Pearson Correlation" = "data/TCS_Pearson.txt")})
        

T2_Drug_Pairs <- reactive({
  
  ##T2_Drugs <- row.names(Drugs_Sigs)
  T2_Drugs <- row.names(T2_Drug_Signatures())
  T2_Drug_Combos <- t(combn(T2_Drugs,2))
})  
  

T2_Table1 <- reactive({
  T2_Drug_SR <- read.table(file=T2_Drug_Similarity_Metrics(),sep="\t",header=TRUE,check.names = FALSE)
  ##T2_Drug_SR <- read.table(file="data/TCS_Weighted_SR.txt",sep="\t",header=TRUE,check.names = FALSE)
  T2_rows <- as.character(T2_Drug_SR$DrugA)
  row.names(T2_Drug_SR) <- T2_rows
  T2_Drug_SR <- T2_Drug_SR[,-1]
  T2_Drug_SR <- as.matrix(T2_Drug_SR)
  H <- T2_Drug_SR[1:10,1:10]
  T2_Drug_SR2 <- melt(T2_Drug_SR)
  
  #T2_Drug_DR <- 
  
  
})


### Text Output: Disease Signature Gene Number ###
output$T2_selected_var2 <- renderText({
  cols <- as.character(colnames(T2_Drug_Signatures()))
  TCGA_Sig2 <- T2_values$Disease_Signature
  length2 <- intersect(cols,as.character(TCGA_Sig2$Genes))
  paste(T2_values$Disease_input,"with" ,length(length2)," genes that are measured by the L1000 Platform")
})




### Tool3  ####
source("tabs/Tool3_Single_Cell_SERVER.R",  local = TRUE)$value


                  

                }






shinyApp(ui, server)